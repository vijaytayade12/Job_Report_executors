package com.test.utilities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class WriteToFile {

	public void writeFile(StringBuilder strigBuilder) {

		File file = new File("D:\\LocalApps\\File_write\\test.txt");
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(file));
			writer.append(strigBuilder);
		} catch (Exception e) {
			e.getMessage();
		} finally {
			if (writer != null)
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	public String systemDateMinusday() {
		DateFormat dateFormat = new SimpleDateFormat("ddMMYYY HH:mm:ss");
		Calendar cal = Calendar.getInstance();

		// Add one day to current date.
		cal.add(Calendar.DATE, 0);
		System.out.println(dateFormat.format(cal.getTime()));
		return dateFormat.format(cal.getTime());
	}

	public String createCheckSum() {

		byte[] data;
		String checksum = null;
		try {
			data = Files.readAllBytes(Paths.get("D:\\LocalApps\\File_write\\test.txt"));
			byte[] hash = null;
			try {
				hash = MessageDigest.getInstance("MD5").digest(data);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			checksum = new BigInteger(1, hash).toString(16);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return checksum;
	}

}
