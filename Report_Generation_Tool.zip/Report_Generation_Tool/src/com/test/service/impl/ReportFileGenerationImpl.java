package com.test.service.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.test.conn.singleton.SingletonCounnectionForJobs;
import com.test.service.ReportFileGeneration;;

public class ReportFileGenerationImpl  {

	/**
	 * @author Vijay 
	 * Method Name getDBParameters - Get all Job details from the
	 *         configuration table
	 * @param - jobName <passing the execution which is inserted into the table>
	 */
	public Map<String, String> getDBParameters(String jobName) throws Exception {

		Map<String, String> parameters = new HashMap<String, String>();
		String query = "SELECT JOB_ID," + "FILE_GEN_PATH," + "FILE_NAME," + "HEADER," + "FOOTER," + "DATE_FORMAT,"
				+ "APPLICATION_NAME," + "EXECUTION_FREQUNCY," + "CRONTAB_DTL ," + "CHECKSUM_ALGO," + "PGP_ENCRYPTION,"
				+ "FILE_DATA_SEPERATION," + "FILE_TYPE," + "DATEMINUS1ORCURRENTDAY," + "CHECKSUM_FLAG,CHECKSUM_TEXT "
				+ "FROM prepareexamdb.job_parameters WHERE JOB_ID=?";
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = SingletonCounnectionForJobs.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, jobName);
			rs = ps.executeQuery();
			while (rs.next()) {
				parameters.put("JOB_NAME", rs.getString("JOB_ID"));
				parameters.put("FILE_GEN_PATH", rs.getString("FILE_GEN_PATH"));
				parameters.put("FILE_NAME", rs.getString("FILE_NAME"));
				parameters.put("HEADER", rs.getString("HEADER"));
				parameters.put("FOOTER", rs.getString("FOOTER"));
				parameters.put("DATE_FORMAT", rs.getString("DATE_FORMAT"));
				parameters.put("APPLICATION_NAME", rs.getString("APPLICATION_NAME"));
				parameters.put("EXECUTION_FREQUNCY", rs.getString("EXECUTION_FREQUNCY"));
				parameters.put("CRONTAB_DTL", rs.getString("CRONTAB_DTL"));
				parameters.put("CHECKSUM_ALGO", rs.getString("CHECKSUM_ALGO"));
				parameters.put("PGP_ENCRYPTION", rs.getString("PGP_ENCRYPTION"));
				parameters.put("FILE_DATA_SEPERATION", rs.getString("FILE_DATA_SEPERATION"));
				parameters.put("FILE_TYPE", rs.getString("FILE_TYPE"));
				parameters.put("DATEMINUS1ORCURRENTDAY", rs.getString("DATEMINUS1ORCURRENTDAY")); // in the table
																									// 0=current day and
																									// 1 means Minus 1
																									// day data need to
																									// retriview
				parameters.put("CHECKSUM_FLAG", rs.getString("CHECKSUM_FLAG"));
				parameters.put("CHECKSUM_TEXT", rs.getString("CHECKSUM_TEXT"));

			}

		} catch (Exception e) {
			e.getMessage();
		}
		return parameters;
	}

	/**
	 * @author Vijay 
	 * Method - genrateExtractionForReport - Generated the data
	 *         extraction report
	 * @param - sqlFilePath - Take the SQL file along with path from environment
	 *          verible <SQL_FILE_WITH_PATH>
	 * @param - jobName Take the jobName from the environment veriable <JOB_NAME>
	 * @param - fileName - Take the file name from environment <GEN_FILE_NAME>
	 */
	public void genrateExtractionForReport(String sqlFilePath, String jobName, String fileName) throws Exception {
		// Get the all parameters from the database for job.
		Map<String, String> params = getDBParameters(jobName);
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuilder addGenFileData = new StringBuilder();
		// jobName = "2way_recon_report";

		try {

			String genFilePath1 = params.get("FILE_GEN_PATH");
			String genFilePath = genFilePath1 + "\\" + fileName;
			String header = params.get("HEADER");
			String footer = params.get("FOOTER");
			String fileDataSeparation = params.get("FILE_DATA_SEPERATION");
			String appName = params.get("APPLICATION_NAME");
			String dateMinus1OrCurrentDay = params.get("DATEMINUS1ORCURRENTDAY");
			String checkSumAlgo = params.get("CHECKSUM_ALGO");
			String checkSumFlag = params.get("CHECKSUM_FLAG");
			String dateFormate = params.get("DATE_FORMAT");
			String checkSumText = params.get("CHECKSUM_TEXT");

			con = SingletonCounnectionForJobs.getConnection();
			ps = con.prepareStatement(getSQLQury(sqlFilePath).toString());
			rs = ps.executeQuery();

			ResultSetMetaData metadata = rs.getMetaData();
			int columnCount = metadata.getColumnCount();
			String col = "";
			for (int i = 1; i <= columnCount; i++) {
				col += metadata.getColumnLabel(i) + params.get("FILE_DATA_SEPERATION");
			}

			if (params.get("HEADER") != null && !params.get("HEADER").equalsIgnoreCase("")) {
				addGenFileData.append(params.get("HEADER") + params.get("FILE_DATA_SEPERATION") + col
						+ params.get("APPLICATION_NAME") + params.get("FILE_DATA_SEPERATION")
						+ sysDateMinus1DayOrCurrentDay(params.get("DATE_FORMAT"), params.get("DATEMINUS1ORCURRENTDAY"))
						+ "\n");
			} else {
				addGenFileData.append(col + "\n");
			}

			int rowCount = 0;
			while (rs.next()) {
				String row = "";
				for (int i = 1; i <= columnCount; i++) {
					row += rs.getString(i) + params.get("FILE_DATA_SEPERATION");
				}
				rowCount++;
				addGenFileData.append(row + "\n");
			}
			System.out.println(addGenFileData);
			// String footer = "TRL|"+rowCount+"|"+dateMinusday;

			if (params.get("FOOTER") != null && !params.get("FOOTER").equalsIgnoreCase("")) {
				addGenFileData.append(params.get("FOOTER") + params.get("FILE_DATA_SEPERATION") + rowCount
						+ params.get("FILE_DATA_SEPERATION") + sysDateMinus1DayOrCurrentDay(params.get("DATE_FORMAT"),
								params.get("DATEMINUS1ORCURRENTDAY")));
			}
			writeFile(addGenFileData, genFilePath);
			if (params.get("CHECKSUM_FLAG").equalsIgnoreCase("Y")) {
				String checkSum = params.get("CHECKSUM_TEXT") + params.get("FILE_DATA_SEPERATION")
						+ fileChecksumGeneration(genFilePath, params.get("CHECKSUM_ALGO"));
				System.out.println(checkSum);
				// stringBuffer.append(checkSum);
				writeFile(addGenFileData.append("\n" + checkSum), genFilePath);
			}
		} catch (Exception e) {
			e.getMessage();
		} finally {
			SingletonCounnectionForJobs.closeConnection(con);
		}

	}

	/**
	 * 
	 */
	public String fileChecksumGeneration(String filePath, String typeOfAlgoforChecksum) throws Exception {

		byte[] data;
		String checksum = null;
		try {
			data = Files.readAllBytes(Paths.get(filePath));
			byte[] hash = null;
			try {
				hash = MessageDigest.getInstance(typeOfAlgoforChecksum).digest(data);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
			checksum = new BigInteger(1, hash).toString(16);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return checksum;
	}

	/**
	 * 
	 */
	public void writeFile(StringBuilder extractedData, String getFileNameWithpath) throws Exception {
		// TODO Auto-generated method stub
		File fileData = new File(getFileNameWithpath);
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(fileData));
			writer.append(extractedData);
		} catch (Exception e) {
			e.getMessage();
		} finally {
			if (writer != null)
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}

	/**
	 * 
	 */
	public String sysDateMinus1DayOrCurrentDay(String dateFormate, String retriviewDataFlag) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat(dateFormate);// ("ddMMYYY HH:mm:ss");
		Calendar cal = Calendar.getInstance();

		// Add one day to current date.
		cal.add(Calendar.DATE, -Integer.parseInt(retriviewDataFlag));
		System.out.println(dateFormat.format(cal.getTime()));
		return dateFormat.format(cal.getTime());
	}

	
	public StringBuffer getSQLQury(String sqlQueryPth) throws Exception {
		// TODO Auto-generated method stub
		StringBuffer addSQLDate = new StringBuffer();

		try {
			// File path is passed as parameter
			File file = new File(sqlQueryPth);
			BufferedReader br = new BufferedReader(new FileReader(file));
			// Declaring a string variable
			String dta;
			while ((dta = br.readLine()) != null) {
				// System.out.println(dta);
				addSQLDate.append(dta);
			}
			System.out.println("=====String Buffer Query=====");
			System.out.println(addSQLDate);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return addSQLDate;
	}

}
