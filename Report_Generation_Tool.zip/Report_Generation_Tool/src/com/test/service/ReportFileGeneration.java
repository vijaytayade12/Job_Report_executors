/**
 * 
 */
package com.test.service;

import java.util.Map;

/**
 * 
 */
public interface ReportFileGeneration {
	
	public Map<String, String> getDBParameters(String jobName) throws Exception;
	
	public void genrateExtractionForReport(String sqlFilePath,String jobName,String fileName) throws Exception;
	
	public String fileChecksumGeneration(String filePath, String typeOfAlgoforChecksum) throws Exception;
	
	public void writeFile(StringBuilder extractedData, String fileNameWithpath) throws Exception;

	public String sysDateMinus1DayOrCurrentDay(String dateFormate,String retriviewDataFlag) throws Exception;
	
	public StringBuffer getSQLQury(String sqlQueryPth) throws Exception; 
	
}
