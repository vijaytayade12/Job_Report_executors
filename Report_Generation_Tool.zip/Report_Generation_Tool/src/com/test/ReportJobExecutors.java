package com.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.test.service.impl.ReportFileGenerationImpl;

public class ReportJobExecutors {

	 protected static final Logger logger = LogManager.getLogger();
	 
	public static void main(String[] args) throws Exception{
		
		logger.info("Calling ReportJobExecutors");
		try {
		System.out.println("=============== Start Job execution ===============");
		ReportFileGenerationImpl reportFileGeneration = new ReportFileGenerationImpl();
		
		String sqlFilePath = System.getenv("SQL_FILE_WITH_PATH");
		String jobName  = System.getenv("JOB_NAME");
		String fileName = System.getenv("GEN_FILE_NAME");
		
		System.out.println("SQL File Path : "+sqlFilePath);
		System.out.println("Job Name : "+jobName);
		System.out.println("Genaration extraction Name : "+fileName);
		reportFileGeneration.genrateExtractionForReport(sqlFilePath, jobName, fileName);
		System.out.println("=============== End Job execution successfully ===============");
		
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		logger.info("End ReportJobExecutors");
	}
	

}
