package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.test.utilities.WriteToFile;

public class ReportGeneration {

	//dign patter
	//https://www.digitalocean.com/community/tutorials/factory-design-pattern-in-java
	public static void main(String[] args) {

		WriteToFile writeToFile = new WriteToFile();
		String dateMinusday = writeToFile.systemDateMinusday();
		//String ss = LocalDateTime.now().toString().formatted("yyyy-dd-M--HH-mm-ss");
		//System.out.println("Date "+ss);
		try {
			StringBuilder stringBuffer = new StringBuilder();
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userservicedb", "root", "root");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from prepareexamdb.users");
			ResultSetMetaData metadata = rs.getMetaData();
		    int columnCount = metadata.getColumnCount();  
		    String col="";
		    for (int i = 1; i <= columnCount; i++) {  
		    	col+=metadata.getColumnLabel(i) + "|";
		    }

	    	stringBuffer.append("HDR|"+col+"TRD|"+dateMinusday+"\n");
	    	int rowCount=0;
		    while (rs.next()) {
		        String row = "";
		        for (int i = 1; i <= columnCount; i++) {
		            row += rs.getString(i) + "|";
		        }
		      rowCount++;
		        stringBuffer.append(row+"\n");
		    }
		    System.out.println(stringBuffer);
		    String footer = "TRL|"+rowCount+"|"+dateMinusday;
		    
		    stringBuffer.append(footer);
		    
		    writeToFile.writeFile(stringBuffer);
		    String checkSum="CHECKSUM|"+writeToFile.createCheckSum();
		    System.out.println(checkSum);
		    //stringBuffer.append(checkSum);
		    writeToFile.writeFile(stringBuffer.append("\n"+checkSum));
			
		}catch (Exception e) {
			e.getMessage();
		}

	}

	private static DateTimeFormatter DateTimeFormatter(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
