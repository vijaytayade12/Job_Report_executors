package com.test.conn.singleton;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SingletonCounnectionForJobs {

	private static SingletonCounnectionForJobs dbInstance;
	private static Connection conn;

	private SingletonCounnectionForJobs() {
	}

	public static SingletonCounnectionForJobs getInstance() {

		if (dbInstance == null) {
			dbInstance = new SingletonCounnectionForJobs();
		}
		return dbInstance;
	}

	public static Connection getConnection() {
		if (conn == null) {
			try {
				String host = "jdbc:mysql://localhost:3306/userservicedb";
				String username = "root";
				String password = "root";
				Class.forName("com.mysql.cj.jdbc.Driver");
				conn = DriverManager.getConnection(host, username, password);
			} catch (SQLException ex) {
				ex.getMessage();
			} catch (Exception e) {
				e.getMessage();
			}
		}

		return conn;
	}
	
	public static void closeConnection(Connection connection)
    {
        try {
            if (connection != null) {
                connection.close();
                connection=null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
