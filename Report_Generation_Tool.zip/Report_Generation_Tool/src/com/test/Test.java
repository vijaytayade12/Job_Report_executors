package com.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> emails = new HashSet<>();
		Pattern patter = Pattern.compile("regex");
		Matcher matcher = null;
		StringBuffer sqlQuery = new StringBuffer();

		try {

			// File path is passed as parameter
			File file = new File("D:\\LocalApps\\workspace\\Report_Generation_Tool\\src\\com\\test\\sample1.sql");

			BufferedReader br = new BufferedReader(new FileReader(file));
			// Declaring a string variable
			String st;
			StringBuffer addSQLDate = new StringBuffer();
			while ((st = br.readLine()) != null) {
				System.out.println(st);
				addSQLDate.append(st);
			}
			System.out.println("=====String Buffer=====");
			System.out.println(addSQLDate);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		for (String e : emails) {
			System.out.println(e);
		}

	}

}
